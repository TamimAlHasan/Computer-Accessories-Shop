set serveroutput on;
create or replace trigger stock_insert
after insert 
on stock 


declare
	theserial stock.serial%TYPE;
	themodel stock.model%TYPE;
	thebrand_name stock.brand_name%TYPE;
	thetype stock.types%type;
	thequantity stock.quantity%TYPE;
	thelocation stock.location%TYPE;
	cursor stock_cursor is
	select * from stock where location='Chittagong';
	
	

begin
	open stock_cursor;
	loop
		fetch stock_cursor into theserial,themodel,thebrand_name,thetype,thequantity,thelocation;
		
		exit when stock_cursor%notfound;
		
		end loop;
		insert into stock2 @site2 values(theserial,themodel,thebrand_name,thetype,thequantity,thelocation);
	close stock_cursor;
	
	
end;
/
commit;