
set serveroutput on;
set verify off;	
declare
	theid employee.id%type := &id;
	thename employee.name%type := '&name';
	thecontact employee.contact%type := '&contact';
	thesalary employee.salary%type := &salary;
	thelocation employee.location%type := '&location';
	
	
	
begin
		insert into employee values
		(theid,thename, thecontact, thesalary,thelocation);

commit;
end;
/