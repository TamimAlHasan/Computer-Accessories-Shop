set serveroutput on;
set verify off;
Declare
	
	getname stock.name%TYPE :='&Brand';
	getresultset SYS_REFCURSOR;
	thequantity stock.quantity%TYPE;
	thelocation stock.location%TYPE;
	
	
begin 
	
	findpc(getname,getresultset);
	LOOP
        FETCH getresultset INTO thequantity,thelocation;
        EXIT WHEN getresultset%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(thequantity ||' '||thelocation);
    END LOOP;
    CLOSE getresultset;

	
end; 
/
commit;