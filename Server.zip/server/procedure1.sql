create or replace procedure findpc
	(p_getname in stock.name%type,p_productdetails OUT SYS_REFCURSOR) 
	IS
	
begin 
	open p_productdetails for select quantity,location from stock where brand_name=p_getname ; 
	
	
end findpc; 
/
commit;