create or replace package body mypackage as 
procedure findemployee
	(p_getmodel in information.model%type,p_employeedetails OUT SYS_REFCURSOR) 
	IS
	
begin 
	open p_employeedetails for 
	select name,contact from employee where id in
	(select employee_id from information where model=p_getmodel ); 
	
	
end findemployee; 


procedure findpc 
	(p_getname in stock.brand_name%type,p_productdetails OUT SYS_REFCURSOR)
	IS
begin 
	open p_productdetails for select quantity,location,model from stock where brand_name=p_getname ;
	
end findpc;


procedure findnoofsells
	(p_selldetails OUT SYS_REFCURSOR)
	IS 
	
begin
	open p_selldetails for
	
	select name,contact,location from employee where id in(select employee.id from employee,information  
	where employee.id=information.employee_id);
end findnoofsells;


procedure findemployeedetails
	(p_getlocation in employee.location%type,p_employeedetails out SYS_REFCURSOR)
	IS
begin 
	open p_employeedetails for
	select name,contact from employee where location=p_getlocation;
end findemployeedetails;

procedure findincome
	(p_findincome out SYS_REFCURSOR) IS
begin 
	open p_findincome for 
	select sum(price) ,brand_name from information group by brand_name order by sum(price) desc;

end findincome;	

procedure bestsell
	(p_findbestsell out SYS_REFCURSOR) IS
begin 
	open p_findbestsell for 
	select count(brand_name),brand_name from information group by brand_name order by count(brand_name) desc; 

end bestsell;	

procedure checkstockout
	(p_findstockout out SYS_REFCURSOR) IS
begin
	open p_findstockout for
	select brand_name,model from stock where quantity=0;
end checkstockout;

procedure updatestock
	(p_getmodel in stock.model%type,
	p_getquantity in stock.quantity%type,
	p_getlocation in stock.location%type) IS
begin
	
		update stock set quantity=quantity+p_getquantity where model=p_getmodel and location=p_getlocation;
		
	
	
	--update stock1 @site1 set quantity=p_getquantity where model=p_getmodel and location=p_getlocation;
	--update stock2 @site2 set quantity=p_getquantity where model=p_getmodel and location=p_getlocation;
end updatestock;


procedure findemployeefromcustomer(
	p_getcustomercontact in information.cust_contact%type,
	p_getmodel in information.model%type,
	p_findemployee out SYS_REFCURSOR
	) IS
begin
	open p_findemployee for
	select name,contact from employee where id in(select employee_id from information where cust_contact=p_getcustomercontact and model=p_getmodel);

end findemployeefromcustomer;
end mypackage;
/
commit;