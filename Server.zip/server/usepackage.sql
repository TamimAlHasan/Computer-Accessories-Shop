set serveroutput on;
set verify off;
Declare
	
	getmodel information.model%TYPE :='&model';
	getresultset SYS_REFCURSOR;
	thename employee.name%TYPE;
	thecontact employee.contact%TYPE;
begin 
	
	mypackage.findemployee(getmodel,getresultset);
	LOOP
        FETCH getresultset INTO thename,thecontact;
        EXIT WHEN getresultset%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(thename ||' '||thecontact);
    END LOOP;
    CLOSE getresultset;
end;
/

Declare 
	getname stock.brand_name%TYPE :='&Brand';
	getid employee.id%type;
	getemployeename employee.name%type;
	getresultset SYS_REFCURSOR;
	thequantity stock.quantity%TYPE;
	thelocation stock.location%TYPE;
	themodel stock.model%TYPE;
begin 
	
	mypackage.findpc(getname,getresultset);	
	LOOP
        FETCH getresultset INTO thequantity,thelocation,themodel;
        EXIT WHEN getresultset%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(thequantity ||' '||thelocation ||' '||themodel);
    END LOOP;
    CLOSE getresultset;

	
end; 
/

declare 
	
	getresultset SYS_REFCURSOR;
	getid employee.id%type;
	getemployeename employee.name%TYPE;
	getemployeecontact employee.contact%TYPE;
	getlocation employee.location%TYPE;
	getcount number;
begin
	mypackage.findnoofsells(getresultset);
	loop
		fetch getresultset into getemployeename,getemployeecontact,getlocation;
		EXIT WHEN getresultset%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE(getemployeename ||' '||getemployeecontact||' '||getlocation);
	end loop;
	close getresultset;
end;
/

declare
	getlocation employee.location%TYPE := '&location';
	getresultset SYS_REFCURSOR;
	getname employee.name%TYPE;
	getcontact employee.contact%TYPE;
	
begin
	mypackage.findemployeedetails(getlocation,getresultset);
	loop
		fetch getresultset into getname,getcontact;
		EXIT WHEN getresultset%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE(getname ||' '||getcontact);
	end loop;
	close getresultset;
end;
/	

declare 
	getincome number;
	getbrandname information.brand_name%TYPE;
	getresultset SYS_REFCURSOR;

begin 
	mypackage.findincome(getresultset);
	loop 
		fetch getresultset into getincome,getbrandname;
		EXIT WHEN getresultset%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE(getincome||' '||getbrandname);
	end loop;
	close getresultset;
end;
/	

declare 
	getbestsell number;
	getbrandname information.brand_name%TYPE;
	getresultset SYS_REFCURSOR;

begin 
	mypackage.bestsell(getresultset);
	loop 
		fetch getresultset into getbestsell,getbrandname;
		EXIT WHEN getresultset%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE(getbestsell||' '||getbrandname);
	end loop;
	close getresultset;
end;
/


declare
		getbrandname stock.brand_name%TYPE;
		getmodel stock.model%TYPE;
		getresultset SYS_REFCURSOR;
begin
	mypackage.checkstockout(getresultset);
		loop 
		fetch getresultset into getbrandname,getmodel;
		EXIT WHEN getresultset%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE(getbrandname||' '||getmodel);
	end loop;
	close getresultset;
end;
/

declare
		getmodel stock.model%TYPE :='&model';
		getquantity stock.quantity%TYPE :=&quantity;
		getlocation stock.location%type :='&location';
		checkupdate stock.quantity%TYPE := 0;
		updatemsg VARCHAR2(100);
		
		
begin
	mypackage.updatestock(getmodel,getquantity,getlocation);
	--select * from stock;
end;
/

declare
		getcustomercontact information.cust_contact%type := '&contact';
		getmodel information.model%TYPE :='&model';
		getresultset SYS_REFCURSOR;
		getemployeename employee.name%TYPE;
		getemployeecontact employee.contact%type;
begin
	mypackage.findemployeefromcustomer(getcustomercontact,getmodel,getresultset);
		loop 
		fetch getresultset into getemployeename,getemployeecontact;
		EXIT WHEN getresultset%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE(getemployeename||' '||getemployeecontact);
	end loop;
	close getresultset;
end;
/

commit;