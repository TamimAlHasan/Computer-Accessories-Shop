set serveroutput on;
declare
	
	theid employee.id%TYPE;
	thename employee.name%TYPE;
	thecontact employee.contact%TYPE;
	thesalary employee.salary%TYPE;
	thelocation employee.location%TYPE;
    
	cursor employee_cursor is
	select * from employee where location='Dhaka';
	
	

begin
	open employee_cursor;
	loop
		fetch employee_cursor into theid,thename,thecontact,thesalary,thelocation;
		
		exit when employee_cursor%notfound;
		
		end loop;
		insert into employee1 @site1 values(theid,thename,thecontact,thesalary,thelocation);
	close employee_cursor;
	
commit;	
end;
/
