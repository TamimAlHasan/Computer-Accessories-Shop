clear screen;

DROP TABLE information CASCADE CONSTRAINTS;

CREATE TABLE information (
	serial varchar(10),
	model varchar(10), 
	brand_name varchar(10), 
	types varchar(10),
	quantity int,
    location varchar(10),
	employee_id int,
	cust_contact varchar(15),
	price int, 
	PRIMARY KEY(serial));
		

commit;
