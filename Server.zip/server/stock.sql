set serveroutput on;
set verify off;	
declare
	theserial stock.serial%type := &serial;
	themodel stock.model%type := '&model';
	thebrandname stock.brand_name%type := '&brand';
	thetypes stock.types%type := '&types';
	thequantity stock.quantity%type := &quantity;
	thelocation stock.location%type := '&location';
	
	
	
begin
		insert into stock (serial,model, brand_name, types, quantity, location) values
		(theserial,themodel, thebrandname, thetypes, thequantity,thelocation);

commit;
end;
/
	

	