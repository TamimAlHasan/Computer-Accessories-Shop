set serveroutput on;
declare
	theserial information.serial%type;
	theid information.id%TYPE;
	thename information.name%TYPE;
	thetype information.types%TYPE;
	theprice information.price%TYPE;
	thelocation information.location%TYPE;
    
	cursor information_cursor is
	select * from information where location='Chittagong';
	
	

begin
	open information_cursor;
	loop
		fetch information_cursor into theserial,theid,thename,thetype,theprice,thelocation;
		
		exit when information_cursor%notfound;
		insert into information2 @site1 values(theserial,theid,thename,thetype,theprice,'Chittagong');
		end loop;
	close information_cursor;
	
	
end;
/
commit;