create or replace package myPackage as 

	procedure findemployee( 
		p_getmodel in information.model%type,
		p_employeedetails OUT SYS_REFCURSOR); 
		
	procedure findpc(
		p_getname in stock.brand_name%type,
		p_productdetails OUT SYS_REFCURSOR);
		
	procedure findnoofsells(
	p_selldetails OUT SYS_REFCURSOR
	);
	
	procedure findemployeedetails(
	p_getlocation in employee.location%type,
	p_employeedetails out SYS_REFCURSOR);
	
	procedure findincome(
	p_findincome out SYS_REFCURSOR
	);
	
	procedure bestsell(
	p_findbestsell out SYS_REFCURSOR);
	
	procedure checkstockout(
	p_findstockout out SYS_REFCURSOR);
	
	procedure updatestock(
	p_getmodel in stock.model%type,
	p_getquantity in stock.quantity%type,
	p_getlocation in stock.location%type
	);
	
	procedure findemployeefromcustomer(
	p_getcustomercontact in information.cust_contact%type,
	p_getmodel in information.model%type,
	p_findemployee out SYS_REFCURSOR
	);
	
end myPackage;
/
