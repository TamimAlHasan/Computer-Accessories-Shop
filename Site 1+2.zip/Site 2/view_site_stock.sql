create or replace view 
myview(view_serial, view_model,view_brand_name,view_types,view_quantity) as
select serial,model,brand_name,types,quantity
from stock @site_link2
where location='Dhaka';

select * from myview;
