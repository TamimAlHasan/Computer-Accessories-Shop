create or replace view myview 
(view_id,view_name,view_contact) as
select id,name,contact from employee @site_link1
where location='Dhaka';

select * from myview;