Set serveroutput on;
set verify off;

DECLARE
  theserial information2.serial%type :='&Serial';
  themodel information2.model%type:='&Model';
  thebrandname information2.brand_name%type:='&Brand';
  thetypes information2.types%type:='&Types';
  thequantity information2.quantity%type :=&Quantity;
  theemployeeid information2.employee_id%type :=&Employee_id;
  thecustcontact information2.cust_contact%type :='&Contact';
  theprice information2.price%type:=&Price;
  thelocation information2.location%type :='Chittagong';
  stock_quan stock2.quantity%type;
  info_quan information2.quantity%type;
  remaining stock2.quantity%type;
  check_quantity stock2.quantity%type;
  stock_out EXCEPTION;
Begin

select quantity into check_quantity 
from stock2 where model=themodel;
if check_quantity<=0 then
     raise stock_out;
else
    insert into information2(serial,model,brand_name,types,quantity,location,employee_id,cust_contact,price)
    values(theserial,themodel,thebrandname,thetypes,thequantity,'Chittagong',theemployeeid,thecustcontact,theprice);

    select quantity into stock_quan
	from stock2  where model=themodel;

--dbms_output.put_line('Stock	Quantity:'||stock_quan||'  and  '||'Information Quantity:'||info_quan);
	remaining :=stock_quan-thequantity;

	update stock2 set quantity=remaining 
	where model =themodel;
	update stock  @site_link2 set quantity=remaining 
	where model =themodel;
	insert into information @site_link2 values(theserial,themodel,thebrandname,thetypes,thequantity,thelocation,theemployeeid,thecustcontact,theprice);

commit;
end if;

EXCEPTION
 when stock_out then
     dbms_output.put_line('Stock Out!');
end;
/