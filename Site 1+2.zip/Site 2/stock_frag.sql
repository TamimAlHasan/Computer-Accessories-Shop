clear screen;
DROP TABLE stock CASCADE CONSTRAINTS;
CREATE TABLE stock2(
    serial int,
    model varchar(10),
    brand_name varchar(10),
    types char(10),
    quantity int,
    location varchar(10),
       PRIMARY KEY(serial));
commit;