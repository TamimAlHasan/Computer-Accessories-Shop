create or replace package myPackage as 
procedure available
	(a OUT SYS_REFCURSOR);
	
	procedure findname
	(p OUT SYS_REFCURSOR);
	
	function sametype
     return SYS_REFCURSOR;
	 
	 procedure findprice
	(prc out SYS_REFCURSOR);
	
	procedure find_employee_sell
	(get_name in varchar,c OUT SYS_REFCURSOR); 
	
end mypackage;
/