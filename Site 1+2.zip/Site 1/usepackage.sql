set serveroutput on
set verify off
declare
	a SYS_REFCURSOR;
	p SYS_REFCURSOR;
	mt SYS_REFCURSOR;
	prc SYS_REFCURSOR;
	c SYS_REFCURSOR;
	theserial stock1.serial%TYPE;
	themodel stock1.model%TYPE;
	thename stock1.brand_name%TYPE;
	thetype stock1.types%TYPE;
	thequantity stock1.quantity%TYPE;
	theserial information1.serial%TYPE;
	themodel information1.model%TYPE;
	thename information1.brand_name%TYPE;
	thetype information1.types%TYPE;
	thequantity information1.quantity%TYPE
	theprice information1.price%TYPE;
	theid information1.employee_id%TYPE;
	input_name employee1.name%TYPE := '&name';
begin
	
	available(a);
	 DBMS_OUTPUT.PUT_LINE('The available products are:');
	 	 DBMS_OUTPUT.PUT_LINE('Serial'||'   '||'Model'||'   '||'Brand_Name'||'    '||'Types'||'    '||'Quantity');
	LOOP
        FETCH a INTO theserial,themodel,thename,thetype,thequantity;
        EXIT WHEN a%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(theserial||' '||themodel||'   '||thename||'   '|| thetype||' '||thequantity);
    END LOOP;
    CLOSE a;
	
	
	
	findname(p);
	LOOP
        FETCH p INTO themodel,thename;
        EXIT WHEN p%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(themodel||' '||thename);
    END LOOP;
    CLOSE p;
	
	
	mt :=sametype;
    LOOP
        FETCH mt INTO themodel,thename,theprice;
        EXIT WHEN mt%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(themodel||' '||thename||' '||theprice);
    END LOOP;
    CLOSE mt;
	
	
	findprice(prc);
	LOOP
        FETCH prc INTO themodel,thename,thetype,thequantity;
        EXIT WHEN prc%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(themodel||' '||thename||' '||thetype||' '||thequantity);
    END LOOP;
    CLOSE prc;
	
	
	find_employee_sell(input_name,c);
	 DBMS_OUTPUT.PUT_LINE('The total amount of sell:');
	 	 DBMS_OUTPUT.PUT_LINE('Total Amount'||'   '||'ID');
	LOOP
        FETCH c INTO theprice,theid;
        EXIT WHEN c%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(theprice||' '||theid);
    END LOOP;
    CLOSE c;
	
	
END;
/
commit;
