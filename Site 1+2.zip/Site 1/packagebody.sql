create or replace package body mypackage as
procedure available
	(a OUT SYS_REFCURSOR) 
	IS
	
begin 
	open a for select serial,model,brand_name,types,quantity from stock1 where quantity>0;
	
	
END available; 

procedure findname
	(p OUT SYS_REFCURSOR) 
	IS
	
begin 
	open p for select model,brand_name from stock1 ; 
	
	
END findname; 

function sametype
  return SYS_REFCURSOR
   AS
   s SYS_REFCURSOR;
BEGIN
 
   open s for select model,brand_name,price from information1 where types='Laptop';


RETURN s;

END sametype;

procedure findprice
	(prc out SYS_REFCURSOR)
	IS
	
begin 

	open prc for select model,brand_name,types,quantity from information1 where price<=70000;
	
end findprice; 


procedure find_employee_sell
	(get_name in varchar,c OUT SYS_REFCURSOR) 
	IS
	
begin 
	
	open c for select SUM(information1.price),information1.employee_id from information1 
	join employee1 on employee1.id=information1.employee_id where employee1.name = get_name 
	group by information1.employee_id;
	
	

end find_employee_sell; 

end myPackage; 
/