set serveroutput on;
declare
  theserial information1.serial%type;
  themodel information1.model%type;
  thebrandname information1.brand_name%type;
  thetypes information1.types%type;
  thequantity information1.quantity%type;
  thelocation information1.location%type;
  theemployeeid information1.employee_id%type;
  thecustcontact information1.cust_contact%type;
  theprice information1.price%type;
  
  cursor information_cursor is
  select * from information1;
  
  
  BEGIN 
   open information_cursor;
   loop
     fetch information_cursor into theserial,themodel,thebrandname,thetypes,thequantity,thelocation,theemployeeid,thecustcontact,theprice;
     exit when information_cursor%notfound;
     insert into information @site_linkm values(theserial,themodel,thebrandname,thetypes,thequantity,thelocation,theemployeeid,thecustcontact,theprice);
   end loop;
   close information_cursor;
   commit;
   end;
   /
  