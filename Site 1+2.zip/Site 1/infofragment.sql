clear screen;

DROP TABLE information1 CASCADE CONSTRAINTS;

create table information1 (
serial varchar(10),
model varchar(10),
brand_name varchar(10),
types varchar(10),
quantity int,
location varchar(10),
employee_id int,
cust_contact varchar(15),
price int,
	primary key(serial));

commit;