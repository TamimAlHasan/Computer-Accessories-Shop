clear screen;

DROP TABLE stock1 CASCADE CONSTRAINTS;

create table stock1 (
serial int,
model varchar(10),
brand_name varchar(10),
types varchar(10),
quantity int,
location varchar(10),
	primary key(serial));

commit;