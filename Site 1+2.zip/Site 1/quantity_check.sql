set serveroutput on;
set verify off;

declare

theserial information1.serial%type :='&serial';
themodel information1.model%type :='&model';
thebrandname information1.brand_name%type :='&brand';
thetypes information1.types%type :='&types';
thequantity information1.quantity%type :=&quantity;
theemployeeid information1.employee_id%type :=&employee_id;
thecustcontact information1.cust_contact%type :=&contact;
theprice information1.price%type :=&price;

check_zero information1.quantity%type;
ex_zero EXCEPTION; 

begin
select quantity into check_zero FROM stock1 where model = themodel;

IF check_zero <= 0 THEN 
      RAISE ex_zero;
ELSE
insert into information1(serial,model,brand_name,types,quantity,location,employee_id,cust_contact,price) 
values(theserial,themodel,thebrandname,thetypes,thequantity,'Dhaka',theemployeeid,thecustcontact,theprice); 
update stock1 set quantity= quantity-thequantity where model= themodel;

insert into information @site_linkm values(theserial,themodel,thebrandname,thetypes,thequantity,'Dhaka',theemployeeid,thecustcontact,theprice); 
update stock @site_linkm set quantity= quantity-thequantity where model= themodel;

commit;

END IF;

EXCEPTION 
   WHEN ex_zero THEN 
      dbms_output.put_line('Stock Out!'); 
 
end;
/
